# распечатать строку "Hello World"
print("Hello World")

