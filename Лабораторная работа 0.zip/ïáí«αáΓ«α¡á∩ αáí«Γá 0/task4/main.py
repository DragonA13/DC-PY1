# TODO объявить переменную var, содержащую в себе строку Hello World
var = "Hello World"
print(var)
