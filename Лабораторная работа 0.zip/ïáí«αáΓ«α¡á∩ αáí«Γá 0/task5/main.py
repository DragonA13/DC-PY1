# TODO распечатать на отдельной строке слово Hello

print("Hello")
print("World")
